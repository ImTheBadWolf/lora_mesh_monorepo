#! /bin/sh
cd /home/pi/lora
python main-web.py
